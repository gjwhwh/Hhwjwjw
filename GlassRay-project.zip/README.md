# GlassRay
کلاینت اندروید با ظاهر شیشه‌ای (Kotlin + Compose).
بیلد: تب Actions ← Build APK ← Run workflow ← دانلود از Artifacts.
